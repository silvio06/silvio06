"""
    input() example
"""
text = input("Type anything... ")  
print(5*text)

num = int(input("Type a number... ")) 
print(5*num)