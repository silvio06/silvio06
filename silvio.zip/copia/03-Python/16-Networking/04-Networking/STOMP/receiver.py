import time
import stomp
    

class MyListener(stomp.ConnectionListener):
# listener che ascolta messaggi da una coda su un server STOMP in tal caso activemq  
    def __init__(self, conn):
        self.conn = conn

    def on_message(self, frame):
#metodo chiamato alla ricezione del messaggio stampando il testo del messaggio, gli headers e il comando del frame ricevuto.
        print('received a message')
        print('text: "%s"' % frame.body)
        print('headers: "%s"' % frame.headers)
        print('cmd: "%s"' % frame.cmd)

if __name__ == "__main__":
    
    conn = stomp.Connection([('127.0.0.1', 61613)])

    conn.set_listener('', MyListener(conn))
#imposta un ascoltatore sulla connessione. Gli ascoltatori vengono utilizzati per gestire eventi specifici che si verificano durante la connessione.
#L'identificatore è una stringa vuota, il che significa che stai assegnando questo ascoltatore all'identificatore predefinito della connessione.

    conn.connect(wait=True)#connette il client STOMP al server.
    conn.subscribe(destination='/queue/test', id=1, ack='auto') 
    #conn.subscribe(destination='/topic/mytesttopic', id=1, ack='auto') 
# Questo sottoscrive il client alla coda denominata '/queue/test' con un ID di sottoscrizione di 1 e l'acknowledgment automatico.
                                                                  

    print('Receiver waiting for messages...')

    time.sleep(60)#ascoltatore attende per ricevere eventuali messaggi

    conn.disconnect()#dopo attesa chiude connesione

# il metodo on_message viene chiamato in modo asincrono 
# ogni volta che un messaggio viene ricevuto sulla coda sottoscritta.
# Questo approccio asincrono consente al programma di eseguire altre operazioni 
# o di rimanere in attesa di ulteriori messaggi senza bloccare il flusso principale di esecuzione.