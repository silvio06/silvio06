import sys, stomp
    

if __name__ == "__main__":

    try:
            MSG = sys.argv[1] # messaggio da inviare 
    except IndexError:
            print("Please, specify MSG arg")

    conn = stomp.Connection([('127.0.0.1', 61613)]) #lista contenente una tupla
    conn.connect(wait=True)
    #wait=True fa sì che la connessione sia stabilita prima di procedere.

    conn.send('/queue/test', MSG)
    #conn.send('/topic/mytesttopic', MSG) # Note: specify the physical name after /topic or /queue when used 
                                          # to send TextMessage to a JMS-based application

    print("Message: -", MSG, "- sent")

    conn.disconnect() #chiusura connessione

#dal terminale amministrativo C:\Program Files\apache-activemq-5.18.3\bin>activemq start
