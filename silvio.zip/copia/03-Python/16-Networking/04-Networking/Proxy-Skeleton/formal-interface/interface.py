from abc import ABC, abstractmethod

class Subject(ABC):

    @abstractmethod
    def request(self, data):
        pass
#La classe Subject  è una classe astratta ed eredita da ABC (Abstract Base Class)
# contiene un metodo astratto request. 
# Le classi che ereditano da Subject sono obbligate a implementare questo metodo.
# Una classe astratta con metodi astratti può essere considerata come la definizione di un'interfaccia.
# Anche se Python non ha un concetto di interfaccia nel senso formale, le classi astratte con metodi astratti fungono spesso da "contratto" che le sottoclassi devono seguire.
# Questo può rendere il codice più prevedibile e semplificare la manutenzione.