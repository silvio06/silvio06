class Subject():

    
    def request(self, data):
        pass
    #in questa funzione non ho ancora implementato la logica interna

#Le sottoclassi possono scegliere se sovrascrivere il metodo request o meno
# dato che la classe Subject non impone la sua implementazione nelle sottoclassi.