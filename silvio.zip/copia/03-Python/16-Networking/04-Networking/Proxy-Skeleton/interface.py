class Subject():

    
    def request(self, data):
        pass
    #in questa funzione non ho ancora implementato la logica interna