import socket
import threading # smodulo gestione thread

# funzione eseguita da ogni thread prende una socket come parametro
def thd_fun(c):


    # data received from client
    data = c.recv(1024)

    # inverte la stringa ricevuta
    data = data[::-1]

    #  Invia la stringa invertita al client.
    c.send(data)

    # connection closed
    c.close()

# verifica se il modulo è eseguito come programma principale.
if __name__ == '__main__':

    host = "" # IP vuoto allora tutte le interfacce disponibili
    cur_port = 0

    # create and bind a TCP socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((host, cur_port))
    cur_port = s.getsockname()[1] # get used port

    print("Socket binded to port", cur_port)

    s.listen(5) #fino a 5 connesioni in attesa
    print("Socket is listening")

    while True: #connessioni in arrivo dai client:

        c, addr = s.accept() #socket e ip client
        print('Connected to :', addr[0], ':', addr[1])

        # start a new thread
        t = threading.Thread(target=thd_fun, args=(c,))
#c è un oggetto socket passato come argomento alla thd_fun. la virgola dopo c è importante anche se passo un solo argomento, in quanto args deve essere una tupla.
        t.start()

    s.close()


