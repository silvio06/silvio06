import socket

msgServer = "Ciao client!"
serverAddressPort = ("localhost".encode("utf-8"), 0) #tupla con ip e port
bufferSize = 1024

s = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)
#Crea una socket con indirizzo IP versione 4 (AF_INET) e protocollo UDP (SOCK_DGRAM)
s.bind(serverAddressPort)

cur_port = s.getsockname()[1]# : porta effettiva a cui il server è vincolato.
# [1] accede al secondo elemento della tupla, che è la porta.
print("server on: localhost, port: ", cur_port)

msgClient, addr = s.recvfrom(bufferSize)
# memorizza il messaggio e l'indirizzo del client
print("[Server]: Messaggio ricevuto: " + msgClient.decode("utf-8"))
print("[Server]: Indirizzo client: {}" .format(addr))

print ("[Server]: Invio dati al client")
s.sendto(msgServer.encode("utf-8"), addr)

s.close()

