import socket

IP = '0.0.0.0'   #ascolto su tutte le interfacce
PORT = 0    #porta scelta dal sistema in automatico
BUFFER_SIZE = 1024

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((IP, PORT))
s.listen(1)

cur_port = s.getsockname()[1] 
#Recupero della porta assegnata dal sistema:
print("server on: ", IP, "port: ", cur_port)

conn, addr = s.accept()#accetta la connesione
print  ('Connection address: {}' .format(addr))
#coppia di valori che rappresentano il socket della connessione (conn) e l'indirizzo del client (addr).
#Connection address: {}': è la stringa di formattazione che contiene un segnaposto {} dove verrà inserito l'indirizzo del client.
toClient= "The world never says hello back!\n"

data = conn.recv(BUFFER_SIZE)
print ("received data: " + data.decode("utf-8"))

conn.send(toClient.encode("utf-8"))

conn.close()
s.close()
# avvio il server python server.py
#avvio il client con python client.py PORT dove port è quello in ascolto del server
