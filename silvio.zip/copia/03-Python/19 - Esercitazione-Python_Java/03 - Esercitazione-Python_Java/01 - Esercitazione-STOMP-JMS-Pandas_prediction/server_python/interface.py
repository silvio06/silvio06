class Service():

    def forecast(self, message):
        pass

    def get_mean(self):
        pass