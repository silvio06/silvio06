package dispatcher;
public interface IDispatcher {

	public void forecast( int valore );
	public float get_mean();

}
