package dispatcher;
public interface IDispatcher {

	public void deposita( int valore );
	public int preleva();

}
