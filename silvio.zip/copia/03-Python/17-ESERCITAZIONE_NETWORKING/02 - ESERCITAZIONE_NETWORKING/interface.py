class Service():

    def deposita(self, message):
        pass

    def preleva(self):
        pass