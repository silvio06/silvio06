package client;


//CHI GENERA LE RICHIESTE 
public class Client {
	
	private static final int N = 10;
	
	public static void main(String[] args) {
//stesse operazini del magazzino dove oltre la coda richiesta creo anche  la coda risposta 

//creo la connesione e il receiver 
//la risposta serve perche il client passa al magazzino la coda su cui si aspetta la connesione


//starto la connesione dato che anche il client prevede un messaggio di risposta 
//creo la sessione non transacted 
//il receiver e nella coda risposta 


//serve il sender ottenuto dalla sessione 
//creo il listner sul receiver
//il receiver passa messaggi al listner 


//ogni client genera 10 messaggi in maniera casuale con math rand a seconda del valore prelevo o deposito 



//se devo prelevare devo creare messaggio con casmpo type avente valore preleva 
//chiedo il prelievo di un id dalla coda 
//la sender posso metterla fuori al if else 
//devo indicare la coda di risposta dato che mi aspetto la risposta
//



//nel caso di deposito faccio la set string e  set int 

//per la deposita non aspetto risposto dato che devo solo inserire 
		//"java.naming.factory.initial", "org.apache.activemq.jndi.ActiveMQInitialContextFactory"
		//"java.naming.provider.url", "tcp://127.0.0.1:61616"

		
		
		//System.out.println("[CLIENT] Mandato messaggio deposita con valore: " + );

		//System.out.println("[CLIENT] Mandato messaggio preleva");
		
		
		
	}
	
}
