package magazzino;

import java.util.Hashtable;

public class Magazzino {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//la prima operazione con la comunicazione activemq e stettare hashtable con i parametri per comunicare col provider 
//nella hashtable ho le prorprieta con una sola coda per il caso in cui il magazzino non conksce la coda su cui rispondere ma la ricava dal client 
//seleziona la coda richiesta usata per ricevere 

//le proprietis servono al contesto allora dichiaro oggetto context a cui passo le proprieta
//ottengo gli administered object usati per comnunicare col provider e le lookup per ottenere la connectionfactory del dominio p2p
//ho una queueconnectoryfactory con casting al tipo ho il primo administered object 

//il secondo e la destination cioe la coda con una lookup per chiedere la coda con  javax.jms 

//stabilisco la connessione che devo avviare perche devo ricevere altrimenti non ho il delivery dalla coda 
//ququeconnection a apartire dalla connectory factory precedente 
//connection.start perche entita che riceve messaggi 

//creo una queue session dopomla sessione 
//creo oggetto queue session 
//receiver per definire che tale entita e un receiver a partire dalla sessione sulla specifica coda ottenuta dal provider tramite jndi
//per la ricezione asincrona sfrutto oggetto magazzinolistener che e una classe che implementa interfaccia 
//il magazzino ad ogni ricezione del msg sulla coda deve essere invocato il listner usando oggetto receive
//MagazzinoLIstener listener e passso istanza al metodo  


		//"java.naming.factory.initial", "org.apache.activemq.jndi.ActiveMQInitialContextFactory"
		//"java.naming.provider.url", "tcp://127.0.0.1:61616"

		
		
		
		System.out.println("[MAGAZZINO] Server avviato");
		
		

	}

}