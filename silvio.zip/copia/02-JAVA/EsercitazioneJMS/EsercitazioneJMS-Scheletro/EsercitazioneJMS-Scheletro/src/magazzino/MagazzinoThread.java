package magazzino;


public class MagazzinoThread extends Thread {
//il thread estare le informazioni
////al thread passo il messaggio con formato mapMessage associato il parametro message con il cast 
//dal messaggio della coda convertito in mapMessage lo passo al magazzino
//faccio la connection cosi  il thtead invia messaggio di risposta 

	public MagazzinoThread ( ){
			
	}
	
	public void run (){
//getstring da il tipo di operazione 
//faccio ipotesi che informazione sul tipo di richiesta e inserita nel mapmessage sotto il valore di chiave
//ottengo la stringa associata al campo type contenuto della chiave 

//getint restituisce un intero e passo la chiave associato a questo campo ID
//nel id ho id del client 

// a seconda del tipo di richiesta preleva o deposita faccio cose diverse
//se il valore ritornato e 0 allora devo deposistare in coda inserendo passando id
//se il valore ritornato non e 0 allora prelevo dalla coda sfrutto codasinch per richiamare preleva e ritorna intero		//System.out.println ( "	[MAGAZZINO-THREAD]: operazione = " +  
	
//dalla connesione attivata precedentemente  creo queuesession di tipo non transcated 

//dalla sessione creo il sender che vuole una coda ottenuta dal messaggio richiesta ottengo la destination che e una coda 
//ottengo la coda risposta e la passo al queuesender 


//creo il messaggio di risposta sfruttando la sessione popolato con chiave type e messaggio relativo alla risposta dato cge il c,ient leggendo il tipo risposta lo riconosce
//con setint ho una prorprieta intera 

//faccio invio del messaggio cosi il thtead recupera le info dal messaggio e scrivo sulla coda risposta inviata dal client al interno del messaggio


//alla fine chiudo il sender e la sessione ma non la connesione che e condivisa ttra tutti i thread altrimenti il prossimo thread creato non avra la connessione

//				+ " , valore = " + );


		//System.out.println ( "	[MAGAZZINO-THREAD]: operazione = " + mm.getString("operazione") );
		
	}
	
	
}