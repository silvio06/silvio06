package magazzino;

import javax.jms.Message;
import javax.jms.MessageListener;
//il compito del magazzino che ad ogni messaggio deve creare un thread che preleva dalla coda o inserisce dalla coda 
//la coda e istanzaiata dal magazzino ed e comune a tutti i thread 
//il thtread deve prelevare prima il tipo di informazioni se si tratta del prelievo deve rispondere usdando la coda del messaggio 
//per inviare il messaagio di risposta necessita della connessione e non della sessione perche pensata per non nessere condivisa tra thread che a partire da essa crea sender e messaggio risposta 
//istanza della coda e connessione passati al listenr 

//creo oggetta coda circolare gestita dal magazzino di DIM=10
//creo il wrapper con metodi sincronized  a cui passo istanza di coda 
//creo un costruttore con due parametri(connection e coda ) che sono variabili della classe


public class MagazzinoListener implements MessageListener{

	@Override
	public void onMessage(Message message) {
//metodo invocato ogni volta che arriva il messaggio su richiesta 
//ad ogni messaggio un thread con operazione di inserimento o preleva sulla coda 	
//creo un thread istanza del magazzinothread e poi lo avvio 




	}

}
