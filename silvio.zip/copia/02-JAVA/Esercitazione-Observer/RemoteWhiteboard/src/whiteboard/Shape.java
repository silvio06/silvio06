package whiteboard;

import java.io.*;

/*
 * extends Serializable per consentire il trasferimento
 * di oggetti non-remoti Shape come argomenti di una invocazione
 * RMI
 */

public interface Shape extends Serializable {
//gli oggetti quadrato e triangolo che implementano interfaccia shape sono serializzati e passati tramite rete al server
	public void draw ();

}