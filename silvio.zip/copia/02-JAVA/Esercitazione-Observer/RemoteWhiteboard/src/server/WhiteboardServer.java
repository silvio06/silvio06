package server;


import java.rmi.registry.*;
import whiteboard.*;

public class WhiteboardServer {
	
	public static void main ( String[] args ){
	
		try{
			
			/*
			 * Creazione e registrazione dell'oggetto remoto. 
			 */
			
			System.out.println ("Creating the object...");
			Whiteboard board = new WhiteboardImpl();
			
			System.out.println (board.toString() + "\n");
			
			Registry rmiRegistry = LocateRegistry.getRegistry();
			//oggetto remoto (board) viene registrato nel registro RMI
			rmiRegistry.rebind( "myWhiteboard" , board);
			System.out.println ("Object registered with name < myWhiteboard > \n" );
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
/*
rebind viene utilizzato dal server per rendere l'oggetto remoto disponibile nel registro RMI,
lookup viene utilizzato dal client per ottenere il riferimento all'oggetto remoto dal registro.
Questa è una delle caratteristiche fondamentali di RMI che consente a client e server di comunicare in modo trasparente attraverso la rete come se gli oggetti remoti fossero oggetti locali.
*/