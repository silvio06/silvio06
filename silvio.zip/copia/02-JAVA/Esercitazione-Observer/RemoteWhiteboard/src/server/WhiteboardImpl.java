package server;
import java.rmi.*;
import java.rmi.server.*;
import java.util.Vector;
import java.util.concurrent.locks.ReentrantLock;

import whiteboard.*;
//implemenatzione oggetto remoto per ereditarieta
public class WhiteboardImpl extends UnicastRemoteObject implements Whiteboard {
	
	
	private int count;
	private Vector<Shape> boardContent;			//contiene le shapes disegnate sulla lavagna elettronica
	private Vector<Observer> attachedObservers;	//contiene gli observer registrati
	
	protected final static long serialVersionUID = 10;
	
	public WhiteboardImpl () throws RemoteException {
		count =0;
		boardContent = new Vector<Shape>();
		attachedObservers = new Vector<Observer> ();
	}
	
	/*
	 * 
	 * TODO (esercizio): gestire la mutua esclusione su addShape
	 * 
	 */
  private ReentrantLock lock= new ReentrantLock();


	public void addShape (	Shape s ) throws RemoteException {
	//service_method
	lock.lock();//acquisisce il lock
    
	//synchronized(boardContent){
//un thread alla volta può eseguire il blocco di codice all'interno delle parentesi graffe

		count = count +1;//incremento numero oggetti
		System.out.println ("\nAdding the shape #" + count + " " + s.toString() );
		
		s.draw();//disegno oggetto
		boardContent.add(s);//aggiungo oggetto al vettore di shape
// notifica gli observer che un client ha invocato il metodo remoto service_method()
		notifyAllObservers();//notifico tutti observer perche si e verificato evento di interesse
	    lock.unlock();
}
	
	
	public Vector<Shape> getShapes () throws RemoteException {
		return boardContent; //ritorna vettore di shape
	}
	
	public void attachObserver ( Observer observer) throws RemoteException{
		
		System.out.println ("\nNew observer attached! \n " + observer.toString() );
		attachedObservers.add( observer );//aggiungo riferiemento al obseerver al vettore di observer
		
	}
	
	/*
	 * Metodo privato per la notifica degli observer registrati.
	 * NOTA: gli Observer sono oggetti remoti
	 */

	private void notifyAllObservers(){

		System.out.println ("(new shape, notify observers! )" );
		int size = attachedObservers.size();//dimensione vettore observer
		
		for ( int i =0; i<size; i++){	
			try{
				attachedObservers.get(i).observerNotify();
			//dalla get(i) ho il riferimento remoto del observer iesimo e su di esso invoco il metodo observernotify 
			}catch(RemoteException e ){
				e.printStackTrace();
			}
	
		}	
	}
}
