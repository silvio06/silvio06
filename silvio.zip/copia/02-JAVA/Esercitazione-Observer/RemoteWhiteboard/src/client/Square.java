package client;

import whiteboard.*;

public class Square implements Shape {
//classe quadrato per disegnare oggetti
	private static final long serialVersionUID = 1L;

	public void draw (){
//il client c passera in un metodo draw oggetti non remoti come square e triangolo che devonon essere serializzati ma non remoti perche non devono essere invocati ma solo disegnati devono implemenatre serializzable
		System.out.println ("+--+");
		System.out.println ("|  |");
		System.out.println ("+--+");
	}
	
}
