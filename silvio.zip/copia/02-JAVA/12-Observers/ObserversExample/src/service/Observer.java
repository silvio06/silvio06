package service;
//seconda interfaccia remota rappresenta observer invocato dal server 
import java.rmi.*;


public interface Observer extends Remote{
//deve essere remota altrimenti il server non riesce a contattare quel oggetto
	
	public void observerNotify () throws RemoteException ;
	//metodo di caallback del server per poter invocare una notifica 
}
//il meccanismo della callback prevede che sia il server ad informare il client del occorenza del evento
//la callback è un invocazione da server a client
//al verificarsi del evento di interesse il server invoca il callback object che era stato creato dal client come oggetto remoto reso invocabile dal server