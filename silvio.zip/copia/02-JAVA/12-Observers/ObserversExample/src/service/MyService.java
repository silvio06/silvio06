package service;
//prima interfaccia remota oggetto che rappresenta il servizio invocato dal client
import java.rmi.*;
//caso con piu client e interfacce da implementare per estendere oggetto remoto

public interface MyService extends Remote{
	
	/*
	 * Metodi per consentire l'attach di un observer
	 * sul subject (Partecipanti del design Pattern 'Observer'); 
	 */
	public void attachObserver ( Observer observer) throws RemoteException;
	//usato per passare al server il riferimento remoto al observer
	//observer passato come parametro è un oggetto remoto
	
	 public void service_method () throws RemoteException ;
	//chiamata dal client al server 
}
