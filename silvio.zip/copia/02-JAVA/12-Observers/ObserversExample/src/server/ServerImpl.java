package server;

import java.rmi.*;
import java.rmi.server.*;
import java.util.Vector;

import service.*;
//caso ereditarieta implementa i due metodi della classe myservice
public class ServerImpl extends UnicastRemoteObject implements MyService {
	private Vector<Observer> attachedObservers;	//contiene gli observer registrati o per meglio dire i riferimenti remoti
	//dalla lista degli observer recupero i riferimenti remoti di ognuno e invoco il metodo observernotify per ogni riferimento remoto
	protected final static long serialVersionUID = 10;
	
	public ServerImpl () throws RemoteException {
		attachedObservers = new Vector<Observer> ();
// l'oggetto viene esportato automaticamente e reso disponibile per le chiamate remote.

	}
	
	public void service_method(){

		System.out.println("service_method() invoked!");

		// notifica gli observer che un client ha invocato il metodo remoto service_method()
		notifyAllObservers();
	}
	
	public void attachObserver ( Observer observer) throws RemoteException{
//sottoscrive un observer sfruttando una variabile membro attachedobserver che acetta oggetti observer
		System.out.println ("\nNew observer attached! \n " + observer.toString() );
		attachedObservers.add( observer ); 
		//aggiunge l' oggetto ricevuto al interno del array
		//
	}
	
	/*
	 * Metodo privato per la notifica degli observer registrati.
	 * NOTA: gli Observer sono oggetti remoti
	 */

	private void notifyAllObservers(){

		System.out.println ("(notify observers! )" );
		int size = attachedObservers.size();
		
		for ( int i =0; i<size; i++){	
			try{ //dalla get(i) ho il riferimento remoto del observer iesimo e su di esso invoco il metodo observernotify esposto dal observer cosi ho la notifica di ognuno degli observer che c0 ha chiesto di registrare verso il server 
				attachedObservers.get(i).observerNotify();
			}catch(RemoteException e ){
				e.printStackTrace();
			}
	
		}	
	}
}
//oggetto observer è il callback object mentre observernotify è callback method 