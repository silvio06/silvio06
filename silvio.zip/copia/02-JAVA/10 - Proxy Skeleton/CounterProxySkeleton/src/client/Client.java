package client;

import service.ICounter;

public class Client {

    public static void main(String args[]) {
        // Verifica se ci sono abbastanza argomenti dalla riga di comando
        if (args.length < 2) {
            System.out.println("Utilizzo: java Client <host> <operazione> [valore]");
            return;
        }

        String host = args[0];
        String operation = args[1];

        // Verifica che l'operazione sia una delle accettate
        if (!operation.equals("sum") &&
                !operation.equals("get") &&
                !operation.equals("sqr") &&
                !operation.equals("inc")) {
            System.out.println("Comando ERRATO! \n Comandi accettati: sum <valore>, get, sqr, inc");
        } else {
            ICounter counter = new CounterProxy(host, 2500);

            if (operation.equals("sum")) {
                try {
                    // Verifica se ci sono abbastanza argomenti per l'operazione "sum"
                    if (args.length < 3) {
                        System.out.println("Utilizzo: java Client <host> sum <valore>");
                        return;
                    }
                    int value = Integer.parseInt(args[2]);
                    counter.sum(value);
                } catch (NumberFormatException e) {
                    System.out.println("ERRORE: l'argomento deve essere un numero!");
                }
            } else if (operation.equals("get")) {
                System.out.println("Valore letto: " + counter.get());
            } else if (operation.equals("sqr")) {
                counter.square();
            } else if (operation.equals("inc")) {
                counter.inc();
            }
        }
    }
}
