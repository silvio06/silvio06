package server;
        
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

import service.Hello;

import java.rmi.registry.LocateRegistry;

public class HelloServer {
        
        
    public static void main(String args[]) {
        
        try {

            HelloServerImplDelega obj_d = new HelloServerImplDelega();

            //Creo un remote object istanziando la classe di implementazione
            //HelloServerImplEreditarieta obj_e = new HelloServerImplEreditarieta(); 
            
            Hello stub = (Hello) UnicastRemoteObject.exportObject(obj_d, 0);

// con registry ho il registro RMI facendo un associazione nome simbolico oggetto 
            Registry registry = LocateRegistry.getRegistry();

 // L'oggetto stub viene registrato nel registro RMI con il nome simbolico "Hello".           
            registry.bind("Hello", stub);
//Nel caso in cui ci sia già un oggetto associato al nome "Hello", questo viene sovrascritto con l'oggetto obj_d.
            registry.rebind("Hello", obj_d);

            System.err.println("Server ready");

        } catch (Exception e) {
            System.err.println("Server exception: " + e.toString());
            e.printStackTrace();
        }
    }
}