package server;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import service.Hello;

// Implementazione per ereditarietà

public class HelloServerImplEreditarieta extends UnicastRemoteObject implements Hello{

    protected HelloServerImplEreditarieta() throws RemoteException {
    //Quando una classe estende un'altra classe in Java,
    //il costruttore della classe figlia può invocare il costruttore della classe genitore utilizzando la parola chiave super()
        super();
    }

    public String sayHello() {
        System.out.println("sayHello() invoked on server...");
        return "Hello, world!"; //ritorno una stringa come parametro di uscita
    }
    
}
