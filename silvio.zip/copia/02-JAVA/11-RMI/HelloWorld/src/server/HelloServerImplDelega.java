package server;

import service.Hello;

// Implementazione per delega

public class HelloServerImplDelega implements Hello{
   
    public HelloServerImplDelega() {
        //eventuali inizializzazioni di stati e risorse 
        //usati per la creazione del oggetto remoto
    }

    public String sayHello() {
        System.out.println("sayHello() invoked on server...");
        return "Hello, world!";
    }
    
}
