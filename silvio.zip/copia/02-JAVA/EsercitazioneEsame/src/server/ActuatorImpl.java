package server;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Random;
import java.util.concurrent.locks.ReentrantLock;

import interfaces.Iactuator;
import interfaces.Ireading;

public class ActuatorImpl extends UnicastRemoteObject implements Iactuator {
    private static final long serialVersionUID = -5457541672194646702L;
    private ReentrantLock lock;

    protected ActuatorImpl() throws RemoteException {
        super();
        lock = new ReentrantLock();
    }

    @Override
    public boolean execute(String typevalue) throws RemoteException {
        boolean result = false;

        lock.lock(); // Acquisizione del lock

        try {
            // Creazione di un oggetto Ireading da typevalue
            Ireading reader = extractReading(typevalue);

            if (reader == null) {
                System.out.println("[Actuator] Formato di input non valido");
                return false;
            }

            String type = reader.getType();
            int value = reader.getValue();

            Random rand = new Random();

            // Ogni richiesta di servizio dura un tempo scelto a caso tra 1 e 5 secondi.
            Thread.sleep((rand.nextInt(5) + 1) * 1000);

            // Scrittura delle informazioni su file (executions.txt) con try-with-resources
            try (FileWriter fw = new FileWriter("executions.txt", true);
                 BufferedWriter bw = new BufferedWriter(fw);
                 PrintWriter pw = new PrintWriter(bw)) {
                pw.write("Tipo di richiesta: " + type + ", Dato: " + value);
                pw.println(); // Aggiungi una nuova linea
                pw.flush();
            } catch (IOException e) {
                e.printStackTrace();
                result = false;
            }

            result = true;
        } catch (InterruptedException e) {
            e.printStackTrace();
            result = false;
        } finally {
            lock.unlock(); // Rilascio del lock
        }

        return result;
    }

    // Metodo per estrarre Ireading da una stringa. aggiungo il metodo extractReading che crea un oggetto Ireading a partire dalla String typevalue
    private Ireading extractReading(String typevalue) {
        try {
            String[] parts = typevalue.split("_"); // Assumendo "_" come separatore
            if (parts.length != 2) {
                return null;
            }

            String type = parts[0];
            int value = Integer.parseInt(parts[1]);

            return new Ireading(type, value);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
