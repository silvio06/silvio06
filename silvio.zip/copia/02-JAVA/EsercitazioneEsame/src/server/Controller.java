package server;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import interfaces.Icontroller;
public class Controller {
    public static void main (String[] args) {
     try{ 
        Registry rmiRegistry=LocateRegistry.getRegistry();
        Icontroller controller=new ControllerImpl();
        rmiRegistry.rebind("controller",controller);
        System.out.println("[ControllerServer] Controller avviato");



     }catch(RemoteException e){e.printStackTrace();}
}
}
