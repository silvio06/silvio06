package server;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import interfaces.Iactuator;
import interfaces.Icontroller;

public class Actuator {
    public static void main (String[] args) {
        try{ 
            Registry rmiRegistry=LocateRegistry.getRegistry();
            Icontroller controller = (Icontroller) rmiRegistry.lookup("controller");
            Iactuator actuator=new ActuatorImpl();
            controller.addActuator(8000);
            System.out.println("[ActuatorServer] Registrato actuator al controller");
			
			
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotBoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}



                

