package server;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Vector;

import interfaces.Iactuator;
import interfaces.Icontroller;
import interfaces.Ireading;

public class ControllerImpl extends UnicastRemoteObject implements Icontroller {
    private static final long serialVersionUID = 2725155631126219696L;
//il controller possiede una lista di actuator registrati
	private Vector<Iactuator> actuators;
	
	protected ControllerImpl() throws RemoteException {
		// TODO Auto-generated constructor stub
		
		actuators = new Vector<Iactuator>();
		
	}

    @Override
    public void addActuator(int port) throws RemoteException {
 // Creo un nuovo oggetto Actuator e lo aggiunge alla lista degli attuatori registrati
           Iactuator actuator = new ActuatorImpl();
        actuators.add(actuator);
        System.out.println("[Controller] Ricevuta nuova registrazione");

    }

    @Override
    public boolean sensorRead(Ireading reading) throws RemoteException {
        // TODO Auto-generated method stub
        boolean result = false;
		int i = 0;
		//result è false !result è true 
		while ((!result) && (i < actuators.size())) {
			//result è true e ci sono sportelli liberi
            // Concatenazione dei due attributi di Reading
            String readingString = reading.getType() + reading.getValue();

			result = actuators.get(i).execute(readingString);
			i++;
		}
		
		System.out.println("[Controller] Richiesta da " + reading + " terminata con esito " + result);
		
		return result;

    }
    
}
