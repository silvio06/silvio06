package client;

import java.util.Random;

import interfaces.*;

public class SensorThread extends Thread {
    Icontroller controller;
    int request;
    public SensorThread(int request,Icontroller controller){
        this.request=request;
        this.controller=controller;
    }
    
    Random rand = new Random();
    public void run() {
        try {
            int value = (int) rand.nextInt(50)+1;
            int x= rand.nextInt(100)+1;
            String type;
            if(x<50)
             type="temperature";
             else
            type="pressure";

            Ireading reading = new Ireading(type, value);

            boolean result=controller.sensorRead(reading);
            System.out.println("Sensor Read Result: " + result);
            

         }catch(Exception e){e.printStackTrace();}
    }
}