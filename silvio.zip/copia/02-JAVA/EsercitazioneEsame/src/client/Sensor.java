package client;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import interfaces.*;
public class Sensor {
    public static void main (String[] args) {
	int T=10;
	int R=10;
    try {
			Registry rmiRegistry = LocateRegistry.getRegistry();
			
			Icontroller controller = (Icontroller) rmiRegistry.lookup("controller");
			//creo un array di oggetti ClientThread di dimensione T
			SensorThread[] threads = new SensorThread[T];
			
			for (int i = 0; i < T; i++) {
				threads[i] = new SensorThread(R,controller);
				threads[i].start();
			}
			
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotBoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		
	}

}

