package interfaces;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Iactuator extends Remote {
    public boolean execute(String typevalue) throws RemoteException;


    
}