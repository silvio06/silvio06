package interfaces;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Icontroller extends Remote {
    public void addActuator(int port) throws RemoteException;
    public boolean sensorRead(Ireading reading) throws RemoteException;
    
}