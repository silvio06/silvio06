package interfaces;

import java.io.Serializable;

public class Ireading implements Serializable{
    private String type;
    private int value;

    public Ireading(String type, int value) {
        this.type = type;
        this.value = value;
    }

    public String getType() {
        return type;
    }

    public int getValue() {
        return value;
    }
}
