package tester;

import coda.*;
import codaimpl.*;

public class TestProgram {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Instanziare una coda circolare SENZA sincronizzazione
		//coda lockfree senza lock inizializzata alla dimensione che voglio aggiungendo i meccanismi di sincronizzazione
		Coda coda =new CodaCircolare(5);
		
	// Instanziare uno dei 'wrapper' (decorator) responsabile della sincronizzazione
	Coda wrapper =new CodaWrapperSynchr(coda);	
	
		
// Creare un array di 100 thread di tipo workerthread per produtrtori e consumatori a seconda del valore del secondo parametro 
	int nthreads = 100;
	WorkerThread[] workers=new WorkerThread[ nthreads ];
	
	
		// Instanziare ed avviare 50 thread di inserimento e 50 di prelievo
		for(int i=0;i<nthreads;i++) {
			if(i%2==0) 
				workers[i]=new WorkerThread ( wrapper, true ); //thread di inserimento
				else
					workers[i]=new WorkerThread ( wrapper, false );//thread di prelievo
			workers[i].start();
			}
		// Attendere la terminazione dei thread
		for(int i=0;i<nthreads;i++) {
			try {
				workers[i].join();
				
			}catch(InterruptedException e) {
				e.printStackTrace();
			}
			}
		}
		
		
		
		
///modificando oggetto wrapper scelgo la sincronizzazione da usare 		
	}
