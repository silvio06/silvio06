package codaimpl;

import coda.*;
public class CodaWrapperSynchr extends CodaWrapper {

	
	public CodaWrapperSynchr( Coda c ){
		super (c);		
	}
	
	
//i blocchi sincronizzati garangtiscono gia la mutua ecslusione per fare il controllo delle condizioni
	//uso le info della coda il monitor java e signal continue uso while 
//se la coda e piena uso wait cosi da mettere in attesa il produttore sulla coda 
//quando sono svegliato richiamo inserisci e con notifyAll con una sola variabile condition non posso
	//risvegliare prodittori e consumatori ma li sposto tutti sulla entry set del monitor 
	public void inserisci( int i){
		
		// Implementare sincronizzazione con blocchi synchronized
		synchronized(coda){
			while(coda.full()) { //signal and continue
				try {
				coda.wait();
			}catch(InterruptedException e) {
				e.printStackTrace();
			}
			
		}
			//esco dal while allora coda liberata posso produrre
			coda.inserisci(i);
			coda.notifyAll();//sveglio tutti 
		}//fine blocco sincronizzato  solo dentro posso usare wait notify notifyAll
		
	}
	
	
	public int preleva(){
		
		//il controllo sulla condizione e sul empty consumo se la coda non e evuota altrimenbti prelevo e 
		//con notifyAll risveglio tutti 
		int x=0;
		synchronized(coda){
			while(coda.empty()) { //finche vuota non posso consumare	
				try {
					coda.wait();
				}catch(InterruptedException e) {
					e.printStackTrace();
				}
				
			}
			x = coda.preleva();
			coda.notifyAll();	
		}
		
		return x;
	}
	
}
