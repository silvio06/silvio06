package server;


import interfaces.ISportello;


public class SportelloImpl implements ISportello{
	
	
	protected SportelloImpl() {
		// TODO Auto-generated constructor stub
		
	}

	@Override
	public boolean serviRichiesta(int idCliente){
		// TODO Auto-generated method stub
		
		
		return false;
	}

}
