package server;

import interfaces.IGestoreSportello;
import interfaces.ISportello;


public class GestoreSportelloImpl implements IGestoreSportello{

	protected GestoreSportelloImpl() {
		// TODO Auto-generated constructor stub
		
	}

	@Override
	public boolean sottoponiRichiesta(int idCliente) {
		// TODO Auto-generated method stub
		
		
		return false;
	}

	@Override
	public void sottoscrivi(ISportello sportello) {
		// TODO Auto-generated method stub
		
		
		
	}

}
