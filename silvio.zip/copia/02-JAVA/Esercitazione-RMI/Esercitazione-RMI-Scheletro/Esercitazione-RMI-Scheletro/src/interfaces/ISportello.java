package interfaces;


public interface ISportello {
	
	boolean serviRichiesta(int idCliente);

}
