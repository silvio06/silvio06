package interfaces;


public interface IGestoreSportello {
	
	public boolean sottoponiRichiesta(int idCliente);
	
	public void sottoscrivi(ISportello sportello);

}
