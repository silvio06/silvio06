package client;


import interfaces.IGestoreSportello;


public class ClientThread extends Thread {
	
	public ClientThread(int requests, IGestoreSportello gestore) {
		
		
	}
	
	public void run() {
		
		
		
	}
	
	

}
