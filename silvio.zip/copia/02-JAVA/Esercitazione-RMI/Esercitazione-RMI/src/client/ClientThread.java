package client;

import java.rmi.RemoteException;
import java.util.Random;

import interfaces.IGestoreSportello;


public class ClientThread extends Thread {
	
	private int requests;
	private IGestoreSportello gestore;
	
	
	public ClientThread(int requests, IGestoreSportello gestore) {
		
		this.requests = requests;
		this.gestore = gestore;
	}
	
	public void run() {
// classe Random è parte del package java.util e fornisce metodi per generare numeri casuali. 	
		Random rand = new Random();
		
		for (int i = 0; i < requests; i++) {
			
			try {
				
				Thread.sleep((rand.nextInt(3) + 1) * 1000);
//tempo di t secondi (t tra 1 e 3 ) il *1000 serve per passare da milli a secondi
				
				int idCliente = rand.nextInt(100)+1;
// idClient è generato in maniera casuale tra 1 e 100.
				boolean result = gestore.sottoponiRichiesta(idCliente);
				
				System.out.println("[ClientThread] Richiesta servita con esito " + result);
				
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	

}
