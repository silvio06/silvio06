package server;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Vector;
import interfaces.IGestoreSportello;
import interfaces.ISportello;


public class GestoreSportelloImpl extends UnicastRemoteObject implements IGestoreSportello {
//classe implementa l'interfaccia Serializable
	private static final long serialVersionUID = 2725155631126219696L;
//il Gestore possiede una lista di Sportelli ordinata in base all’ordine delle sottoscizioni
	private Vector<ISportello> sportelli;
	
	protected GestoreSportelloImpl() throws RemoteException {
		// TODO Auto-generated constructor stub
		
		sportelli = new Vector<ISportello>();
		
	}

	@Override
	public boolean sottoponiRichiesta(int idCliente) throws RemoteException {
	// prende in carico le richieste di servizio dei Client e le smista allo sportello
		
		boolean result = false;
		int i = 0;
		//result è false !result è true 
		while ((!result) && (i < sportelli.size())) {
			//result è true e ci sono sportelli liberi
			result = sportelli.get(i).serviRichiesta(idCliente);
			i++;
		}
		
		System.out.println("[Gestore] Richiesta da " + idCliente + " terminata con esito " + result);
		
		return result;
//il Gestore restituisce al Client esito true se puo smistare la richiesta ad uno sportello libero
// Il Gestore restituisce esito false se ogni Sportello restituisce false,ovvero nessuno puo accogliere la richiesta

	}

	@Override
	public void sottoscrivi(ISportello sportello) throws RemoteException {
		// usata dallo sportello al proprio avvio per sottoscriversi al gestore
		
		sportelli.add(sportello);
		//aggiungo lo sportello alla lista di sportelli gia presenti 
		
		System.out.println("[Gestore] Ricevuta nuova sottoscrizione");
		
	}

}
