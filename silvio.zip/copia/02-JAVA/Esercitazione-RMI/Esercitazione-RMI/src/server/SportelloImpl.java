package server;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Random;
import java.util.concurrent.Semaphore;

import interfaces.ISportello;


public class SportelloImpl extends UnicastRemoteObject implements ISportello{
//identificatore univoco associato a una versione specifica di una classe serializzabile
// Quando una classe viene serializzata, l'ObjectOutputStream scrive anche il valore serialVersionUID nel flusso di output.
	private static final long serialVersionUID = -5457541672194646702L;
	//gestione della concorrenza tramite semafori
	private Semaphore maxReqs;
	private Semaphore maxConcurrentReqs;
	
	//costruttore inizializza le risorse 
	protected SportelloImpl() throws RemoteException {
		// TODO Auto-generated constructor stub
		
		maxReqs = new Semaphore(5);
		maxConcurrentReqs = new Semaphore(3);
		
	}

	// implementazione effettiva dei servizi
	@Override
	public boolean serviRichiesta(int idCliente) throws RemoteException {
		// TODO Auto-generated method stub
		
		boolean result = false;
		
		if (!maxReqs.tryAcquire()) {
		//se ho raggiunto il massimo numero di richieste  devo fermarmi
		//tryAcquire(): Tenta di acquisire un permesso dal semaforo. Se il permesso è disponibile, lo acquisisce e restituisce true. Se il permesso non è disponibile, restituisce immediatamente false senza bloccarsi.
			
			System.out.println("[Sportello] Raggiunto limite richieste");
			System.out.println("[Sportello] Richiesta da " + idCliente + " non servita");
			return result; //stampa false 
		}
		
		try { //Acquisizione del semaforo per richieste simultanee:
			
			maxConcurrentReqs.acquire();
			
			Random rand = new Random();
	//Ogni richiesta di servizio dura un tempo scelto a caso tra 1 e 5 secondi. 
			Thread.sleep((rand.nextInt(5) + 1) * 1000);
	//Al termine della richiesta idCliente è salvato su un file		
			FileWriter fw = new FileWriter("requests.txt", true);
//primo parametro nome del file, secondo parametro (true) 
//indica che si desidera aprire il file in modalità "append", 
//consentendo di aggiungere nuovi dati alla fine del file esistente anziché sovrascrivere il file.
			BufferedWriter bw = new BufferedWriter(fw); 
// tipo di writer che memorizza i dati in un buffer prima di scriverli effettivamente sul disco.

			PrintWriter pw = new PrintWriter(bw); 
//classe in Java che estende Writer e fornisce metodi di stampa formattati utilizzata per scrivere testo su un flusso di output, 
			pw.println(idCliente);
			pw.flush();
//forza il buffer a essere svuotato, garantendo che i dati siano scritti effettivamente nel file anziché rimanere nel buffer.
			
			pw.close();
			bw.close();
			fw.close();
			
			result = true;
			
			System.out.println("[Sportello] Servita richiesta da " + idCliente);
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = false;
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = false;
			
		} finally {//Rilascio dei semafori
			maxConcurrentReqs.release();
			maxReqs.release();
		}
		
		return result;
	}

}
