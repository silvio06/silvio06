package queueapp;

import java.util.Hashtable; //property

import javax.jms.*; //java message service
import javax.naming.*; //srvizio di naming offerto da jndi
//lato sender non devo avviare la connessione a meno che il sender non fa da receiver
//altrimenti i messaggi non sono inviati al oggetto in esecuzione
public class Sender {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//proprieta con coppia chiave valore di tipo stringa
		Hashtable<String, String> prop = new Hashtable<String, String> ();
		//prima proprieta è la factory initial con valore url del provider
		prop.put( "java.naming.factory.initial", "org.apache.activemq.jndi.ActiveMQInitialContextFactory" );
		//seconda proprieta è la provider url con valore indirizzo endpoint con porto
		prop.put( "java.naming.provider.url", "tcp://127.0.0.1:61616" );
		
		//specificare il nome JNDI per una coda
		prop.put( "queue.test", "mytestqueue" );
		
		
		try{
		//definisco il contesto con associazione nome oggetto 
			Context jndiContext = new InitialContext(prop);
			
			// Lookup per i due administered objects 
			QueueConnectionFactory queueConnFactory = (QueueConnectionFactory)jndiContext.lookup("QueueConnectionFactory");
			//destination
			Queue queue = (Queue)jndiContext.lookup("test"); // il prefisso "queue." non fa parte del nome jndi
		
    		//uso della connectionfactory per creare la connessione
    		QueueConnection queueConn = queueConnFactory.createQueueConnection();

    		//dalla connseione creo la sessione non transcated e ack automatico
    		QueueSession queueSession = queueConn.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);

			//dalla sessione creo le entita di invio messaggi
    	    QueueSender sender = queueSession.createSender(queue);
			//messasggi di tipo testo contengono stringa
			TextMessage message = queueSession.createTextMessage();
           
            for ( int i =0; i<5; i++){ //invio multiplo di messaggi
            	message.setText("hello_" + i);
            	sender.send( message );
            }

 //ulteriore invio di messaggio usato dal receiver per fare una attesa attiva       
            message.setText("fine");
            sender.send( message );
             
            System.out.println ("I messaggi sono stati inviati!");
            
            // clean up risorse 
            sender.close();
            queueSession.close();  
            queueConn.close();
            
    		
    		
			
		}catch(Exception e ){
			e.printStackTrace();
		}
		
	}

}
// terminale amministrativo dalla cartella bin di activemq activemq start
//activemq permette la comunicazione tra microservizi come un sender che invia messaggi al receiver e di mezzo ce il Messagebroker activemq 
//entro in queues da activemq esso è il canale usato per lo scambio dei messaggi
//java -cp .;C:\Programmi\apache-activemq-5.18.3\activemq-all-5.18.3.jar queueapp.Sender
