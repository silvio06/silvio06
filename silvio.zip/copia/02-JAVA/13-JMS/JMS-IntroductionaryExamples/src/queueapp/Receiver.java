package queueapp;

import java.util.Hashtable;

import javax.jms.*;
import javax.naming.*;
//funge da consumatore che è in ascolto di messaggi
public class Receiver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Hashtable<String, String> prop = new Hashtable<String, String> ();
		
		prop.put( "java.naming.factory.initial", "org.apache.activemq.jndi.ActiveMQInitialContextFactory" );
		prop.put( "java.naming.provider.url", "tcp://127.0.0.1:61616" );
		
		//		jndi queue name   queue-name
		prop.put( "queue.test", "mytestqueue" );
		
		try{
			Context jndiContext = new InitialContext(prop);
			
			// Lookup administered objects 
			QueueConnectionFactory queueConnFactory = (QueueConnectionFactory)jndiContext.lookup("QueueConnectionFactory");
			Queue queue = (Queue)jndiContext.lookup("test"); // il prefisso "queue." non fa parte del nome jndi
			
		//uso della connectionfactory per creare la connessione	
    		QueueConnection queueConn = queueConnFactory.createQueueConnection();
			// a differenza del sender va anche avviata la connessione
    		queueConn.start();
    		//creo la sessione di tipo non transacted e ck in automatico
    	    QueueSession queueSession = queueConn.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
			//creo entita che riceve i messaggi
    	    QueueReceiver receiver = queueSession.createReceiver(queue);
    	   
			//i messaggi che ricevo sono di tipo testo
    	    TextMessage message; 
            //resto in attesa di messaggi finche il sendeer non li avra inviati tutti 
            do{
            	System.out.println ("In attesa di messaggi!");
            	message = (TextMessage)receiver.receive();
            	System.out.println ("	+ messaggio ricevuto: " + message.getText());
            }while (message.getText().compareTo("fine") != 0); 
             //attesa termine quando il sender invia  message.setText("fine"); 
             //chiudo le risorse aperte          
            receiver.close();
            queueSession.close();
            queueConn.close(); 
		}catch(Exception e ){
			e.printStackTrace();
		}

	}

}
