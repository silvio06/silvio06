package pubsubapp_asynch;

import java.util.Hashtable;

import javax.jms.JMSException;
import javax.jms.Session;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicSession;
import javax.jms.TopicSubscriber;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class Subscriber {
//questo consumer si sottoscrive al topic jms del calcio in modalita asincrona

	public static void main(String[] args) throws NamingException, JMSException {
		
		Hashtable<String, String> properties = new Hashtable<String, String>();
		properties.put("java.naming.factory.initial","org.apache.activemq.jndi.ActiveMQInitialContextFactory");
		properties.put("java.naming.provider.url","tcp://127.0.0.1:61616");	
		properties.put("topic.soccer" , "soccernews"); //consumes from the topic soccernews 
		Context jndiContext = new InitialContext(properties);

		TopicConnectionFactory tcf = (TopicConnectionFactory)jndiContext.lookup("TopicConnectionFactory");
		Topic soccer = (Topic)jndiContext.lookup("soccer");

		TopicConnection tc = tcf.createTopicConnection();
		//sottoscrizione duratura al topic del calcio
		tc.setClientID("MakeItLastConn_1"); //to be used in case of Durable subscription 

		TopicSession ts = tc.createTopicSession(false, Session.AUTO_ACKNOWLEDGE);
		//TopicSubscriber subscriber = ts.createSubscriber(soccer);
		TopicSubscriber subscriber = ts.createDurableSubscriber(soccer, "MakeItLastConn_1");
//ho creato un entita subscriber duraturo nel caso esso non è sempre attivo il publisher puo fare lo stesso il delivery dei messaggi	
		
		//TopicSubscriber subscriber = ts.createSubscriber(soccer, "propInt=10", false);

		MyListener msgl = new MyListener();//terza entita per ricezione asincrona
		subscriber.setMessageListener(msgl);

		tc.start();  // tells the messaging provider to start message delivery
		
		System.out.println("Listener set...");
		
		/*subscriber.close(); // When these three lines are commented, the subscriber keeps on listening
		ts.close();
		tc.close();*/
		
			}

}
// la ricezione asincrona non preve la chisura della connesione ne delle atre risorse aperte  
// Una sottoscrizione duratura è una sottoscrizione a un topic JMS che mantiene la memoria dello stato anche quando il subscriber non è attivo.
// Per supportare sottoscrizioni durature, è necessario associare un identificatore di client (ClientID) univoco al subscriber.
// Sono particolarmente utili in scenari in cui il subscriber potrebbe disconnettersi e riconnettersi, ma è importante che non perda alcun messaggio
// in una coda o un topic JMS, un listener può essere utilizzato per gestire la ricezione di nuovi messaggi appena vengono pubblicati o consegnati.
// Invece di dover eseguire un loop continuo per controllare la presenza di nuovi eventi o messaggi, il listener è attivato solo quando effettivamente si verifica un evento.
// Nel metodo onMessage del listener, puoi definire come l'applicazione deve rispondere a ciascun messaggio ricevuto, ad esempio elaborando i dati contenuti nel messaggio o eseguendo operazioni specifiche in base al contenuto del messaggio.