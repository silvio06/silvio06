package pubsubapp_asynch;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

class MyListener implements MessageListener{

	@Override
	public void onMessage(Message arg0) {
//Il metodo onMessage viene chiamato quando un messaggio viene ricevuto(arg0 è il messaggio ricevuto)
		TextMessage mymsg = (TextMessage)arg0;
//Il messaggio ricevuto viene convertito a un oggetto TextMessage. Si presume che i messaggi siano di tipo testuale.
		System.out.println("Receiving messages ...");
		try {//elaborazione del messaggio
			String msg = mymsg.getText();//estrae testo del messaggio
			System.out.println("I am a subscriber. I read the following message ->" + msg);
			System.out.println("The int property of the message is: " + mymsg.getIntProperty("propInt"));
		} catch (JMSException e) {
			e.printStackTrace();
		}
		
	}
	
}
