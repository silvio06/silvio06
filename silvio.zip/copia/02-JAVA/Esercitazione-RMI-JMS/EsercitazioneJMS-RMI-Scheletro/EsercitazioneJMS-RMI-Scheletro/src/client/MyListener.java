package client;

import javax.jms.Message;
import javax.jms.MessageListener;

public class MyListener implements MessageListener {
	
	@Override
	public void onMessage(Message arg0) {
		
		
	}

}
