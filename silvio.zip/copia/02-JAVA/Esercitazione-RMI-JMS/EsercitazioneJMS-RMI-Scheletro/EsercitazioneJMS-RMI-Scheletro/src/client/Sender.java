package client;


public class Sender implements Runnable {
	
	@Override
	public void run() {
		
		
	}

}
