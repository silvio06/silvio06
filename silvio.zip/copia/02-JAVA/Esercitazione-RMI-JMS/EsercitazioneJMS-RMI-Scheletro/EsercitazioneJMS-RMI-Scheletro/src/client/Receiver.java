package client;


public class Receiver implements Runnable {
	
	@Override
	public void run() {
		
		
	}

}
