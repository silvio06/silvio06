package proxy;


public class Receiver implements Runnable {
	
	@Override
	public void run() {
		
		
			
	}
	
}
