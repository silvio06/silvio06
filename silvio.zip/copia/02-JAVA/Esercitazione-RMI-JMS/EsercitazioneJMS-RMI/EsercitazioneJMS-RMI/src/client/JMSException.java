package client;

public class JMSException {

}
