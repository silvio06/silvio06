package server;

import interfaces.*;

import java.net.*;
import java.io.*;

public abstract class Skeleton implements Iactuator {


	public void runSkeleton() {
	//invocato dalla classe server alla ceazione dello skeleton per ereditarieta
		
		ServerSocket serverSocket = null;//socket server tcp
		Socket socket = null; //socket client 
		
		try {
			
			serverSocket = new ServerSocket(8000); //socket server
			System.out.println("actuator in ascolto sulla porta 8000");
			
			while (true){//server sempre attivo
				
				socket = serverSocket.accept(); //accetta richesta dal client
				SkeletonThread st = new SkeletonThread(socket, this);
				st.start();//starto istanza thread creata 
			}
			
		} catch (IOException e) {
			// Eccezione dovuta alle socket
			e.printStackTrace();
		}
	}

}
		