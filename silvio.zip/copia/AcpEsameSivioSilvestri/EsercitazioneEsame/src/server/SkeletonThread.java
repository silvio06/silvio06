package server;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

import interfaces.*;

public class SkeletonThread extends Thread{
		
		Socket s;
		Iactuator actuator;
		
		public SkeletonThread (Socket s, Iactuator actuator){
			
			this.s = s;
			this.actuator = actuator;
		}
		
		public void run() {//quello che deve fare il thread quando e avviato
			
			try {
				
				DataOutputStream ostream = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));
			    DataInputStream istream = new DataInputStream(new BufferedInputStream(s.getInputStream()));
		 
			    // lettura dell'operazione
				String operation = istream.readUTF();
			    System.out.println("Servo l'operazione: " + operation);

	    	    if (operation.equals("sum")) {
			    	//lettura di un intero dal flusso di input
			    	String value = istream.readUTF();
			    	actuator.execute(value);
                    ostream.writeBoolean(actuator.execute(value));
                    ostream.flush();
                }
                
			} catch (IOException e) {
				// Eccezione dovuta alle socket
				e.printStackTrace();
			}
		}
}
