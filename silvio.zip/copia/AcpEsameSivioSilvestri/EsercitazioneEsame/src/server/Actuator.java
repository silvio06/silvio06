package server;

public class Actuator { 
	
	public static void main(String[] args) {
    		
		ActuatorImpl actuator = new ActuatorImpl();
		actuator.runSkeleton();
		
		
	}
	
}