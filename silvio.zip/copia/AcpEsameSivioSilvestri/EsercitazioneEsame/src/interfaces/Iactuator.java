package interfaces;


public interface Iactuator  {
    public boolean execute(String typevalue) ;


    
}