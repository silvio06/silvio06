package client;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import service.Hello;
//Creare  una classe client da cui intendi richiamare l'oggetto remoto.
public class HelloClient {

    private HelloClient() {}

    public static void main(String[] args) {

        //String host = (args.length < 1) ? null : args[0];

        try {
            // ottiene il riferimento all'oggetto Hello remoto

            /*  specificare l'host per fare il lookup

                // Registry registry = LocateRegistry.getRegistry(host);
            */ 
            //ottengo registro rmi con registry ho trasparenza di locazione
            Registry registry = LocateRegistry.getRegistry(null);
         //Recupera l'oggetto dal registro col metodo lookup a cui passo
         // un valore stringa che rappresenti il ​​nome del bind come parametro.
         // il valore di ritorno è l'oggetto remoto con downcast al tipo hello
            Hello stub = (Hello) registry.lookup("Hello");
            // invocazione del metodo remoto sayHello()
            String response = stub.sayHello();//invocato come fosse locale al client
            System.out.println("response: " + response);
        
        } catch (Exception e) {
            System.err.println("Client exception: " + e.toString());
            e.printStackTrace();
        }
    }
}
//tre terminali dalla bin del progetto dove ci sono .class
// start rmiregistry
//java server.HelloServer
//java client.HelloClient
//il server istanzia oggetto remoto ed è in attesa di richieste dal client
//oggetto remoto riceve invocazione dal client e stampa una stringa che era dentro al oggetto remoto
//nel client non indico dove sta il server ,a dove sta il registry con nome simbolico del oggetto remoto 
// se sbaglio il nome simbolico il registry non puo restituire il riferimento 
//il dispacher gira le richieste dal client al metodo del server 