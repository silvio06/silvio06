package threadpipe;
import java.io.PipedOutputStream;

public class Test {
	
	public static void main(String[] args)  {
		PipedOutputStream pipeOut = new PipedOutputStream();//flusso di uscita
		
		WriterThread w = new WriterThread (pipeOut); //creo due thread
		ReaderThread r = new ReaderThread (pipeOut);
		
		w.start();//avvio i thread creati 
		r.start();
		
		
	}

}
