package server;

public class Server { 
	
	public static void main(String[] args) {
    		
		CounterImpl count = new CounterImpl();

		//CASO 1: avvio dell'oggetto remoto per ereditarieta'
		//count.runSkeleton();
	
		//CASO 2: avvio dell'oggetto remoto per delega
		CounterSkeletonDelega skelDelega = new CounterSkeletonDelega( count );
		//passo come paramatero il riferimento al oggetto del servizio reale
		//anche i metodi sono un invocazione sul servizio reale
		skelDelega.runSkeleton();
		
	}
	
}
//output sia per delega che ereditarieta è lo stesso,cambia solo la strutturazione