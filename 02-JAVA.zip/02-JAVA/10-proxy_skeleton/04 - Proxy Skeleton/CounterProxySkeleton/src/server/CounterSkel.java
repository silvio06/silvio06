package server;

import service.*;

import java.net.*;
import java.io.*;

public abstract class CounterSkel implements ICounter {

	
	public void runSkeleton() {
	//invocato dalla classe server alla ceazione dello skeleton per ereditarieta
		
		ServerSocket serverSocket = null;//socket server tcp
		Socket socket = null; //socket client 
		
		try {
			
			serverSocket = new ServerSocket(2500); //socket server
			System.out.println("Server in ascolto sulla porta 2500");
			
			while (true){//server sempre attivo
				
				socket = serverSocket.accept(); //accetta richesta dal client
				SkeletonThread st = new SkeletonThread(socket, this);
				st.start();//starto istanza thread creata 
			}
			
		} catch (IOException e) {
			// Eccezione dovuta alle socket
			e.printStackTrace();
		}
	}

}
		