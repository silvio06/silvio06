package server;

//CASO 2: implementazione per delega
import service.*;

public class CounterImpl implements ICounter {

//CASO 1: implementazione per ereditarieta'
//public class CounterImpl extends CounterSkel {

	private int count;
	
	public CounterImpl() {
		count = 0;
	}
	
	public int get() {
		return count;
	}

	//metodi gestiti con concorrenza un solo thread alla volta accede 
	public synchronized void inc() {
		count++;
	}

	
	public synchronized void sum (int value)  {
		count += value;
	}
	
	public  synchronized void square(){
		count=count*count;
	}
	
}
// questa classe implementa i servizi effettivi offerti dal interfaccia Icounter