package client;

import java.rmi.registry.*;

import service.*;

/*
 * InvokerClient agisce da client che invocherà prettamenete il metodo remoto 
 * service_method() fornito dal servizio remoto MyService
 */

public class InvokerClient {

	public static void main ( String[] args ){
		try{
			
			//1-Ottiene il riferimento al servizio remoto
			Registry rmiRegistry = LocateRegistry.getRegistry();
			//2-chiede il riferimento remoto del servizio myservice 
			MyService stub_myservice = (MyService)rmiRegistry.lookup("myservice");
			System.out.println ("Got reference < myservice > " );
			System.out.println ( stub_myservice.toString() );
			//3-Invoca il metodo remoto di MyService per registrare l'observer (attachObserver)
			stub_myservice.service_method();		
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
 //totale 4 terminali 1 server 2 client e rmiregistry
 //1 start rmiregistry
 //2 java server.Server che registra il servizio remoto sul registry stampando il riferimento remoto contenente ip del enpoint, numero porto e object id 
 //3 java client.ObserverClient istanzia observer cosi da generare oggetto remoto observer e invocato attachobserver sul riferimento remoto del servizio s
 //4 java client.InvokerClient il client invoca servicemethod sulservizio remoto cosi da scaturire invocazione observernotify su tutti gli observer registrati in tal caso ne ho registrato uno solo ma basta aprire altri terminali e lanciare nuovamente java client.ClientObserver
 //il client ha il riferimento a myservice lo stampa ,il server riceve invocazione del metodo e stampa la stringa presente al interno della notifyallobserver che scansione array prende il riferimento remoto ottenuto dal attachobserver per notificare observer 
 //ho un meccanismo di callback distribuita con rmi sfruttando i riferimeti remoti come parametri di metodi cosi che il server invoca oggetti remoti senza chiederli al registry ma ottenuti dal client. il server deve gestire tutti questi riferimenti 