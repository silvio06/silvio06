package client;

import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageListener;

public class ClientListener implements MessageListener{
//MESSAGGI SULLA CODA RISPOSTA stampati a video interessa id 
//faccio la conversione in un mapMessage del message generico dopo stampo id con getint e parametro int
//il client riceve messaggio sulla coda risposta e sara invocato il message 
	@Override
	public void onMessage(Message message) {

		//System.out.println("[CLIENT-LISTENER] Ricevuto messaggio dalla coda 'Risposta' : " + );
		
		
		
	}
	
}
