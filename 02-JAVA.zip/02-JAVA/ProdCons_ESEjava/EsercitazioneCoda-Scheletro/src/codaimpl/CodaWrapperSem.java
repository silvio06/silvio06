package codaimpl;

import coda.*;
import java.util.concurrent.*; //uso dei semafori
public class CodaWrapperSem extends CodaWrapper {

	
// Inserire 2 semafori quando il produtore produce e quando il consumatore consuma ho 2 code
//due semafori due accodamenti da gestire
	private Semaphore msg;
	private Semaphore space; //acquisito dal produttoree rilasciato dal consumatore
	
	
	public CodaWrapperSem ( Coda c ){
		super (c);
		
		// Inizializzare semafori 0 elementi presenti in coda
		msg=new Semaphore(0,false);
		//dimensione della coda e la quantita di elementi inseribili nella coda
		space=new Semaphore(coda.getSize(),false); 
		
	}
	
	
	public void inserisci( int i){
		
		// Implementare sincronizzazione con semafori
		try {
			//un singolo thtread puo fare inserimento 
//altrimenti chiamano in concorrenza la inserisci devo garantire la mutua esclusione sul inserisci della coda
			
			space.acquire(); //ho bisogno di spazio per produrre
//uso un blocco sincronizzato
			synchronized(coda) {
			
			coda.inserisci(i); //proteggo la parte di mutua esclusione
			}
			
			
		}catch (InterruptedException e) {e.printStackTrace();
   }finally {msg.release(); }//sveglio i consumatori in attesa di messaggio disp
		
				
	}
	
	
	public int preleva(){
		
		int x=0;
		try { 
			msg.acquire(); //il consumatore puo prelevare dati ci sono messaggi disponibili.
		    synchronized(coda) {
		    x = coda.preleva();  //accesso alla coda in mutua ecslusione
		}

		}catch (InterruptedException e) {e.printStackTrace();
		   }finally {space.release(); } //risveglio il produttore che era bloccato sul acquire in attesa di spazio disponibile
		return x; //valore consumato
	}
	
	
}