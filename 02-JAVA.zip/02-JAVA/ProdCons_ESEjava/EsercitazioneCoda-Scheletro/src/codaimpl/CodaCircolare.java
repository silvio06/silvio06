package codaimpl;

import coda.*;


/*
 * implementazione della coda circolare --> lock free
 */

public class CodaCircolare implements Coda {
	
	
	private int data[];	//gli elementi sono memorizzati in un array gestito in maniera circolare
	
	private int size;
	private int elem;

	
	private int tail; 
	private int head;  //testa della coda 
	
	

	public CodaCircolare( int s){ //size della coda 
		size=s;
		elem=0; //inizialmente nessun elemento in coda 
		data = new int[size];
		tail=head=0; //inizialmente testas e coda coincidono
	}
	
	// metodi di utilita'

	public boolean full(){
		if ( elem == size )
			return true; //coda piena
		return false; // la coda non è piena
	}
	
	public boolean empty(){
		if( elem == 0)
			return true; //coda vuota
		return false; //coda non vuota
	}
	
	public int getSize(){
		return size; //num elementi nella coda
	}
	

	//inserisce un elemento in coda in posizione tail
	
	public void inserisci( int i ){
		data[ tail%size ] =i;
		
		//condizione di attesa se la coda è piena non posso produrre
		try{
			Thread.sleep(101 + (int)(Math.random()*100)  ); //sleep di durata random max pari a 200ms
		}catch ( InterruptedException e ){
			e.printStackTrace();
		}
		
		elem=elem+1; //ho inserito un elemento
		System.out.println ("inserito " + i + " (tot = " + elem + " )");
		tail=tail+1; //sposto la coda 
	}
	
	
	//estrae un elemento dalla testa
	public int preleva (){
		int x = data[ head%size ]; //ritorna il valore prelevato
		
		//condizione di attesa se la coda è vuota non posso consumare
		try{
			Thread.sleep(101 + (int)(Math.random()*400)  ); //sleep di durata random max pari a 500ms
		}catch ( InterruptedException e ){
			e.printStackTrace();
		}
		
		
		elem=elem-1; //ho consumato
		System.out.println ("				prelevato " + x + " (tot = " + elem + " )");
		
		head=head+1; //aggiorno la testa
		return x; //valore consumato
	}
	
	

}