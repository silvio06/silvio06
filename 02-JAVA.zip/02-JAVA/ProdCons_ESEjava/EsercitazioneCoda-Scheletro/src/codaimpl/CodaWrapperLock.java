package codaimpl;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

import coda.*;

public class CodaWrapperLock extends CodaWrapper {//estende la classa astratta 
	
	// Inserire Lock e variabili condition
//variabili memebro lock e due variabili memebro condition una per i produttori e una consumatore 
	
	private ReentrantLock lock;
	private Condition empty;
	private Condition full;
	
	
	public CodaWrapperLock( Coda c ){
		super (c);
		
		// Inizializzare lock e variabili condition
		lock=new ReentrantLock();
		empty =lock.newCondition();
		full=lock.newCondition();
	}
	
	
	public void inserisci( int i){
		lock.lock();
	
		
		
		try {
			while(coda.full())
	//signal and continue verifico sempre al risveglio se la condizione e verificata 
				empty.await();
			coda.inserisci(i);

			
		}catch (InterruptedException e) {e.printStackTrace();
   }finally { lock.unlock();}
		// Implementare sincronizzazione con lock e variabili condition		
				
	}
	
	
	public int preleva(){ //metodi non presenti nellla classe CodaCircolare
		
		int x=0;
     lock.lock();
	
		
		
		try {
			while(coda.empty())
	//signal and continue verifico sempre al risveglio se la condizione e verificata 
				full.await();
			x= coda.preleva();
           empty.signal();
			
		}catch (InterruptedException e) {e.printStackTrace();
   }finally { lock.unlock();}
				
		return x;
	}

	
}
