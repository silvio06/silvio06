package coda;
//programma muktithread con produttore consumatore e 
//meccanismi di sincronizzazione a aseconda del wrapper

public interface Coda {
	
	public void inserisci( int i);
	public int preleva();
	public boolean empty();
	public boolean full();
	public int getSize();
}
