package client;

import whiteboard.*;
//questo client chiede al sever di registrare observer che richiede attach alla callback remoto del observer e il server deve notificare obserer ogni volta che viene disegnato un elemento sulla lavagna infine gli observer alla ricezione della notifica devono contattare la lavagana per chiedere lo stato e ottenerre gli elelemti stampati
import java.rmi.registry.*;

public class WhiteboardClient2 {

	public static void main ( String[] args ){
		try{
			
			
			
			/*
			 * 1-Ottiene il riferimento alla lavagna remota.
			 * 2-Crea l'oggetto callback (ObserverImpl)
			 * 3-Invoca il metodo remoto di Witheboard per registrare l'observer 
			 */
			
			
			Registry rmiRegistry = LocateRegistry.getRegistry();
			Whiteboard board = (Whiteboard)rmiRegistry.lookup("myWhiteboard");
			System.out.println ("Got reference < myWhiteboard > " );
			System.out.println ( board.toString() );
			/*
			 * il callback object viene creato lato client e poi verrà passato come parametro
			 * al metodo remoto esportato dal server, ovvero attachObserver
			 */
			Observer observer = new ObserverImpl( board );
			
			System.out.println ("\nObserver with ref: " );
			System.out.println ( observer.toString());
			
			board.attachObserver( observer);
					
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
}
//totale 4 terminali 1 sever 2 client e rmiregistry
//1 start rmiregistry
//2 java server.WhiteboardServer
//3 java client.WhiteboardClient2 genera oggetto remoto observer e invocato attachobserver sul riferimento remoto
//4 java client.WhiteboardClient1 richieste di stampa con aggiunta di shape quadrato e traiangolo
//