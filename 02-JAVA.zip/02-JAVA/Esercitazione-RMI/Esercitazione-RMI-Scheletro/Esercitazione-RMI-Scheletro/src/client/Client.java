package client;


public class Client {
	
	public static void main (String[] args) {
		
		int T = 10;
		int R = 10;
		
				
		
	}

}
