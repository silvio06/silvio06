class Subject():

    
    def request(self, data):
        pass